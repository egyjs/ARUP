


public class classification {

String classification_attributes;
int repetition;

    public classification(String classification_attributes, int repetition) {
        this.classification_attributes = classification_attributes;
        this.repetition = repetition;
    }

    public String getClassification_attributes() {
        return classification_attributes;
    }

    public void setClassification_attributes(String classification_attributes) {
        this.classification_attributes = classification_attributes;
    }

    public int getRepetition() {
        return repetition;
    }

    public void setRepetition(int repetition) {
        this.repetition = repetition;
    }



    
}
