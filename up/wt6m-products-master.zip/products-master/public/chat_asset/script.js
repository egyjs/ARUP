
$(document).ready(function (){

    var chat_path = window.location.pathname.split("/").pop();
    $('.contact_'+chat_path).addClass("active");
    $(".messages").animate({ scrollTop: $('.messages')[0].scrollHeight }, "fast");
     var url = document.head.querySelector('meta[name="url"]').content;
     var token = document.head.querySelector('meta[name="csrf-token"]').content;

    $('.contact').click(function(){
        window.location.href=url+'/chat/rooms/'+$(this).attr("room");
    });

    var list = [];

    $('.contact').each(function (){
        var user = $(this).attr('user');
        list.push(user);
    });

        var socket = io.connect("http://localhost:5000", {
            query: 'userid='+userid+'&username=' +username+'&list='+list.join(',')
        });

        socket.on('is_online',(data) => {
            console.log('is online user id '+data.user_id + ' my stuts is : ' + data.stuts);

            if (data.stuts == 'online') {
                $('.'+data.user_id).removeClass('offline');
                $('.'+data.user_id).addClass(data.stuts);
            }else {
                $('.'+data.user_id).removeClass('online');
                $('.'+data.user_id).addClass(data.stuts);
            }

        });

        socket.on('iam_online',(data) => {

            console.log('iam  user id : ' + data.user_id + 'is : ' + data.stuts);
            if (data.stuts == 'online') {
                $('.'+data.user_id).removeClass('offline');
                $('.'+data.user_id).addClass(data.stuts);
            }else {
                $('.'+data.user_id).removeClass('online');
                $('.'+data.user_id).addClass(data.stuts);
            }

        });
        socket.on('iam_offline',(data) => {

            console.log('iam offline user id : ' + data.user_id + 'is : ' + data.stuts);

                $('.'+data.user_id).removeClass('online');
                $('.'+data.user_id).addClass(data.stuts);

        });



        socket.on('connect',function (data) {

            $('.contact').each(function (){
                var user = $(this).attr('user');
                socket.emit('check_online', {
                        user_id : user
                });
            });
        });



        /////////////////// Messages ////////////
        $('.message_form').submit(function (e){
                e.preventDefault();
                var serial  = $(this).serialize();
                var message = $('.message_form input[name="message"]').val();
                var element = $('.message_form input[name="element"]').val();
                var room = $('.message_form input[name="room"]').val();
                if($('.message_form input[name="message"]').val() != null){
                if(room_status == 0){

                    $.ajax({
                        url : url+'/messages/add',
                        method : 'POST',
                        data : serial,
                        dataType : 'json',
                        beforeSend:function (){
                            $('.message_form input[name="message"]').val("");
                            $('<li class="replies"><img src="'+$('#profile-img').attr('src')+'" alt="" /><p>' + message + '</p></li>').appendTo($('.messages ul'));
                            $('.contact.active .last').html('<span>You: </span>' + message);
                            $(".messages").animate({ scrollTop: $('.messages')[0].scrollHeight }, "fast");
                        },
                    success : function (e){
                    if(e.success == "please try again"){
                        alert("please try again");
                    }
                        if(e.success == "true"){
                            socket.emit('share',{
                            element : element,
                            message: message,
                            room: room,
                        });
                        }
                    },
                    error: function (request, status, error) {
                        console.log(request);
                        console.log(status);
                        console.log(error);
                    }
                });
               }
            }
        });



    $("#block_room").click(function (e){
        e.preventDefault();
        var room = $(this).attr("room");
        var serial = "_token="+ token + "&room="+ room;
        $.ajax({
             url : url+'/rooms/block',
             method : 'POST',
             data : serial,
             dataType : 'json',
             beforeSend:function (){
            },
             success : function (e){
               if(e.success){
                   if(e.success == "block"){
                       $('.message_form input[name="message"]').val("Sorry You can't replay to this converstion").css('text-align','center').attr('disabled','disabled');
                       $("#block_room").text("Unblock");
                       room_status = 1;
                   }
                   else if(e.success == "unblock"){
                        $('.message_form input[name="message"]').val("").css('text-align','left').removeAttr('disabled');
                        $("#block_room").text("Block");
                       room_status = 0;
                   }
                    socket.emit('report_block_status',{
                    element : "element_"+e.element,
                    room: room,
                    room_status: room_status,
                });
               }
             },
             error: function (request, status, error) {
                console.log(request);
                console.log(status);
                console.log(error);
            }
         });
    });


    socket.on('back_report_block_status',function (data){
           room_status = data.room_status;
        if(data.room_status == 1){
            $('.message_form input[name="message"]').val("Sorry You can't replay to this converstion").css('text-align','center').attr('disabled','disabled');
            $("#block_room").css('cursor','not-allowed');

        }
        else{
            $('.message_form input[name="message"]').val("").css('text-align','left').removeAttr('disabled');
            $("#block_room").css('cursor','pointer');
        }

    });

    $('.voice').click(function() {
           startRecording();
          });
          $('.voice').dblclick(function() {
          stopRecording();
          });
    });


$("#profile-img").click(function() {
	$("#status-options").toggleClass("active");
});

$(".expand-button").click(function() {
  $("#profile").toggleClass("expanded");
	$("#contacts").toggleClass("expanded");
});

$("#status-options ul li").click(function() {
	$("#profile-img").removeClass();
	$("#status-online").removeClass("active");
	$("#status-away").removeClass("active");
	$("#status-busy").removeClass("active");
	$("#status-offline").removeClass("active");
	$(this).addClass("active");

	if($("#status-online").hasClass("active")) {
		$("#profile-img").addClass("online");
	} else if ($("#status-away").hasClass("active")) {
		$("#profile-img").addClass("away");
	} else if ($("#status-busy").hasClass("active")) {
		$("#profile-img").addClass("busy");
	} else if ($("#status-offline").hasClass("active")) {
		$("#profile-img").addClass("offline");
	} else {
		$("#profile-img").removeClass();
	};

	$("#status-options").removeClass("active");
});
