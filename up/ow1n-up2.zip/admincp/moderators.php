<?php
/**
* @Package: Maqola
* @Version: 1.5.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','moderators');

	if(!$moderators->has_permission('moderators')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.moderator_name LIKE '%$search%' 
									  OR A.moderator_email LIKE '%$search%'
									  OR A.moderator_mobile LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			
			if(count($params)){
				$baseURL = 'moderators.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'moderators.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.moderator_id", PREFIX_DB . "moderators A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.moderator_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*,
			(SELECT  COUNT(*) FROM " . PREFIX_DB . "quotes C WHERE C.moderator_id=A.moderator_id ) AS quotes_count
			FROM " . PREFIX_DB . "moderators A
			$hook_sql $sql_order $sql_limit ;" );
			$moderators_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$moderators_list [] = $data ;
			}
		
			include $Maqola->tpl('moderators') ;
		break;
	
		
		case 'addmoderator':
			$is_editmoderator = false ;			
			$moderatordata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				
				if(!is_mail($_POST['moderator_email'])){
					$Maqola->msg($lang['moderator_email_wrong']);
				}
				
				if(mb_strlen(trim($_POST['moderator_name'])) < 3){
					$Maqola->msg($lang['moderator_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['moderator_pass'])) < 6){
					$Maqola->msg($lang['moderator_pass_wrong']);
				}
					
				if(!intval($_POST['moderator_role'])){
					$Maqola->msg($lang['moderator_role_select']);
				}
				
				
				
				$data   = array();
				$data['moderator_email'] = dataforsql(trim($_POST['moderator_email']),true) ;
				$data['moderator_name'] = $moderators->moderator_name(trim($_POST['moderator_name'])) ;
				$data['moderator_role'] = intval($_POST['moderator_role']);
				$data['moderator_pass'] = $moderators->moderator_pass(trim($_POST['moderator_pass'])) ;
				$data['moderator_time'] = time();
				
				$check = $Maqola->select(array('moderator_name'=>$data['moderator_name']),'moderators','LIMIT 1',' AND 1=1 ');
				if($check){
					$Maqola->msg($lang['moderator_name_already_registered']);
				}
				
				$check = $Maqola->select(array('moderator_email'=>$data['moderator_email']),'moderators','LIMIT 1',' AND 1=1 ');
				if($check){
					$Maqola->msg($lang['moderator_email_already_registered']);
				}
				
				$moderator_id = $Maqola->insert($data,'moderators');
				$Maqola->msg($lang['moderators_add_successfully'],'moderators.php');
				exit;
			} 
		
			include $Maqola->tpl('moderators_add') ;
		break;
		
		case 'editmoderator':
			$is_editmoderator = true ;
			
			$moderatordata = $Maqola->select(array('moderator_id'=>intval($_GET['id'])),'moderators');
			
			if(!$moderatordata['moderator_id']){
				$Maqola->go_to('moderators.php');
			}
			
			if($moderatordata['moderator_id'] == 1){
				$Maqola->go_to('moderators.php');
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				
				if(!is_mail($_POST['moderator_email'])){
					$Maqola->msg($lang['moderator_email_wrong']);
				}
				
				if(mb_strlen(trim($_POST['moderator_name'])) < 3){
					$Maqola->msg($lang['moderator_name_wrong']);
				}
				
					
				if(!intval($_POST['moderator_role'])){
					$Maqola->msg($lang['moderator_role_select']);
				}
				
				
				$data   = array();
				$data['moderator_email'] = dataforsql(trim($_POST['moderator_email']),true) ;
				$data['moderator_name'] = $moderators->moderator_name(trim($_POST['moderator_name'])) ;
				$data['moderator_role'] = intval($_POST['moderator_role']);
				if(!empty($_POST['moderator_pass'])){
					if(mb_strlen(trim($_POST['moderator_pass'])) < 6){
						$Maqola->msg($lang['moderator_pass_wrong']);
					}
					$data['moderator_pass'] = $moderators->moderator_pass(trim($_POST['moderator_pass'])) ;
				}
				
				$check = $Maqola->select(array('moderator_name'=>$data['moderator_name']),'moderators','LIMIT 1',' AND moderator_id <> '.$moderatordata['moderator_id']);
				if($check){
					$Maqola->msg($lang['moderator_name_already_registered']);
				}
				
				if(is_mail($data['moderator_email'])){
					$check = $Maqola->select(array('moderator_email'=>$data['moderator_email']),'moderators','LIMIT 1',' AND moderator_id <> '.$moderatordata['moderator_id']);
					if($check){
						$Maqola->msg($lang['moderator_email_already_registered']);
					}
				}
				
				$Maqola->update($data,$moderatordata['moderator_id'],'moderators','moderator_id');
				$Maqola->msg($lang['moderators_edit_successfully'],'moderators.php');
				exit;
			} 
			
			$moderatordata['moderator_permissions'] = explode(',',$moderatordata['moderator_permissions']);
			include $Maqola->tpl('moderators_add') ;
		break;
	
		case 'delmoderator':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
				
				
			$moderatordata = $Maqola->select(array('moderator_id'=>intval($_GET['id'])),'moderators');
			if(!$moderatordata['moderator_id']){
				$Maqola->go_to('moderators.php');
			}
			
			if($moderatordata['moderator_id'] == 1){
				$Maqola->go_to('moderators.php');
			}
			
			$Maqola->delete(array('moderator_id'=>$moderatordata['moderator_id']),'moderators');
			$Maqola->go_to('moderators.php');
		break;
	}
 
?>