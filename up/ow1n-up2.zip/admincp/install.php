<?php
/**
 * @Package: Maqola
 * @Version: 1.0.0
 * @Author: ProductPHP
 * @Author URI: https://khamsat.com/user/productphp
 */

date_default_timezone_set("Asia/Riyadh");
define('__Maqola__','ok');
include "../system/functions.php";
include "../system/config.php";

$cp_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$cp_link = explode('admincp/',$cp_link);
$cp_link = $cp_link[0] ;

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(250) NOT NULL,
  `site_url` varchar(250) NOT NULL,
  `site_email` varchar(250) NOT NULL,
  `site_desc` varchar(250) NOT NULL,
  `site_terms` mediumtext NOT NULL,
  `site_perpage` int(10) NOT NULL,
  `code_html` longtext NOT NULL,
  `site_facebook` varchar(250) NOT NULL,
  `site_twitter` varchar(250) NOT NULL,
  `site_instagram` varchar(250) NOT NULL,
  `site_youtube` varchar(250) NOT NULL,
  `site_google` varchar(250) NOT NULL,
  `site_snapchat` varchar(250) NOT NULL,
  `site_telegram` varchar(250) NOT NULL,
  `t1_header_title` int(10) NOT NULL,
  `t1_header_logo` int(10) NOT NULL,
  `t1_bg_color` varchar(100) NOT NULL,
  `t1_font_color` varchar(100) NOT NULL,
  `t1_img_logo` varchar(250) NOT NULL,
  `t1_img_bg` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;");

$settings    = $Maqola->select(array('id'=>1),'settings');
if(!$settings['id']) {
    $Maqola->query("INSERT INTO `maqola_settings` (`id`, `site_name`, `site_url`, `site_email`, `site_desc`, `site_terms`, `site_perpage`, `code_html`, `site_facebook`, `site_twitter`, `site_instagram`, `site_youtube`, `site_google`, `site_snapchat`, `site_telegram`, `t1_header_title`, `t1_header_logo`, `t1_bg_color`, `t1_font_color`, `t1_img_logo`, `t1_img_bg`) VALUES
(1, 'مقولة', '".dataforsql($cp_link,true)."', '', 'موسوعة مقولة للإقتباسات والمقولات بالعربية', '', 0, '', '#', '#', '#', '', '#', '', '', 0, 0, '', '', '', '');") ;
}else{
    $Maqola->query("UPDATE `maqola_settings`SET site_url='".dataforsql($cp_link,true)."' WHERE id=1 ") ;
}

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_moderators` (
  `moderator_id` int(10) NOT NULL AUTO_INCREMENT,
  `moderator_name` varchar(250) NOT NULL,
  `moderator_fullname` varchar(250) NOT NULL,
  `moderator_address` mediumtext NOT NULL,
  `moderator_email` varchar(250) NOT NULL,
  `moderator_pass` varchar(32) NOT NULL,
  `moderator_mobile` varchar(30) NOT NULL,
  `moderator_lastip` varchar(250) NOT NULL,
  `moderator_time` int(10) NOT NULL,
  `moderator_role` int(10) NOT NULL,
  `moderator_permissions` longtext NOT NULL,
  `moderator_status` int(10) NOT NULL,
  `moderator_code` varchar(30) NOT NULL,
  `moderator_notes` mediumtext NOT NULL,
  PRIMARY KEY (`moderator_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;");

$moderators    = $Maqola->select(array('moderator_id'=>1),'moderators');
if(!$moderators['moderator_id']) {
    $Maqola->query("INSERT INTO `maqola_moderators` (`moderator_id`, `moderator_name`, `moderator_fullname`, `moderator_address`, `moderator_email`, `moderator_pass`, `moderator_mobile`, `moderator_lastip`, `moderator_time`, `moderator_role`, `moderator_permissions`, `moderator_status`, `moderator_code`, `moderator_notes`) VALUES(1, 'admin', 'الإسم', '', 'admin@local.host', 'c9208744eb8fe083a7c32fdacf45cc78', '', '', 0, 1, '', 0, '', '');") ;
}



$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_sources` (
  `source_id` int(10) NOT NULL AUTO_INCREMENT,
  `source_name` varchar(250) NOT NULL,
  `source_desc` varchar(250) NOT NULL,
  `source_image` varchar(250) NOT NULL,
  `source_time` int(10) NOT NULL,
  `source_views` int(10) NOT NULL,
  `source_notes` mediumtext NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`source_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_authors` (
  `author_id` int(10) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(250) NOT NULL,
  `author_desc` varchar(250) NOT NULL,
  `author_image` varchar(250) NOT NULL,
  `author_time` int(10) NOT NULL,
  `author_views` int(10) NOT NULL,
  `author_notes` mediumtext NOT NULL,
  `author_nationality` varchar(250) NOT NULL,
  `author_specialty` varchar(250) NOT NULL,
  `author_date_birth` varchar(250) NOT NULL,
  `author_date_death` varchar(250) NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_categories` (
  `category_id` int(10) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(250) NOT NULL,
  `category_desc` varchar(250) NOT NULL,
  `category_image` varchar(250) NOT NULL,
  `category_time` int(10) NOT NULL,
  `category_views` int(10) NOT NULL,
  `category_notes` mediumtext NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_quotes` (
  `quote_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_content` mediumtext NOT NULL,
  `quote_note` mediumtext NOT NULL,
  `quote_date` varchar(250) NOT NULL,
  `quote_image` varchar(250) NOT NULL,
  `quote_featured` int(10) NOT NULL,
  `quote_time` int(10) NOT NULL,
  `quote_views` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `source_id` int(10) NOT NULL,
  `author_id` int(10) NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`quote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;




$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_quotes` LIKE 'category_ids';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD `category_ids` VARCHAR(500) NOT NULL AFTER `author_id`, ADD `author_ids` VARCHAR(500) NOT NULL AFTER `category_ids`, ADD `source_ids` VARCHAR(500) NOT NULL AFTER `author_ids`;") ;
}


$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_quotes` LIKE 'quote_title';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD `quote_title` VARCHAR(250) NOT NULL AFTER `quote_id`;") ;
    $Maqola->query("ALTER TABLE `maqola_categories` CHANGE `category_desc` `category_desc` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;") ;
    $Maqola->query("ALTER TABLE `maqola_authors` CHANGE `author_desc` `author_desc` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;") ;
    $Maqola->query("ALTER TABLE `maqola_sources` CHANGE `source_desc` `source_desc` MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL;") ;
    $Maqola->query("ALTER TABLE `maqola_categories` ADD `category_count` INT(10) NOT NULL AFTER `category_views`;") ;
    $Maqola->query("ALTER TABLE `maqola_authors` ADD `author_count` INT(10) NOT NULL AFTER `author_views`;") ;
    $Maqola->query("ALTER TABLE `maqola_sources` ADD `source_count` INT(10) NOT NULL AFTER `source_views`;") ;
    $Maqola->query("ALTER TABLE `maqola_categories` ADD UNIQUE(`category_id`);") ;
    $Maqola->query("ALTER TABLE `maqola_authors` ADD UNIQUE(`author_id`);") ;
    $Maqola->query("ALTER TABLE `maqola_sources` ADD UNIQUE(`source_id`);") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD UNIQUE(`quote_id`);") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD INDEX( `category_id`, `source_id`, `author_id`);") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD INDEX(`category_ids`);") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD INDEX(`author_ids`);") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD INDEX(`source_ids`);") ;
}

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_articles` (
  `article_id` int(10) NOT NULL AUTO_INCREMENT,
  `article_seo_title` varchar(600) NOT NULL,
  `article_seo_desc` varchar(600) NOT NULL,
  `article_seo_keys` varchar(600) NOT NULL,
  `article_title` varchar(250) NOT NULL,
  `article_content` mediumtext NOT NULL,
  `article_desc` mediumtext NOT NULL,
  `article_date` varchar(250) NOT NULL,
  `article_image` varchar(250) NOT NULL,
  `article_featured` int(10) NOT NULL,
  `article_time` int(10) NOT NULL,
  `article_views` int(10) NOT NULL,
  `category_id` int(10) NOT NULL,
  `source_id` int(10) NOT NULL,
  `author_id` int(10) NOT NULL,
  `category_ids` varchar(500) NOT NULL,
  `author_ids` varchar(500) NOT NULL,
  `source_ids` varchar(500) NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`article_id`),
  UNIQUE KEY `article_id` (`article_id`),
  KEY `category_id` (`category_id`,`source_id`,`author_id`),
  KEY `category_ids` (`category_ids`(333)),
  KEY `author_ids` (`author_ids`(333)),
  KEY `source_ids` (`source_ids`(333))
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;

$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_moderators` LIKE 'moderator_lastvisit';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_moderators` ADD `moderator_lastvisit` INT(10) NOT NULL AFTER `moderator_time`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `site_redirect_old` INT(10) NOT NULL AFTER `site_perpage`;") ;
    $Maqola->query("ALTER TABLE `maqola_sources` ADD `source_seo_title` VARCHAR(600) NOT NULL AFTER `source_id`, ADD `source_seo_desc` VARCHAR(600) NOT NULL AFTER `source_seo_title`, ADD `source_seo_keys` VARCHAR(600) NOT NULL AFTER `source_seo_desc`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `site_seo_title` VARCHAR(600) NOT NULL AFTER `id`, ADD `site_seo_desc` VARCHAR(600) NOT NULL AFTER `site_seo_title`, ADD `site_seo_keys` VARCHAR(600) NOT NULL AFTER `site_seo_desc`;") ;
    $Maqola->query("ALTER TABLE `maqola_categories` ADD `category_seo_title` VARCHAR(600) NOT NULL AFTER `category_id`, ADD `category_seo_desc` VARCHAR(600) NOT NULL AFTER `category_seo_title`, ADD `category_seo_keys` VARCHAR(600) NOT NULL AFTER `category_seo_desc`;") ;
    $Maqola->query("ALTER TABLE `maqola_authors` ADD `author_seo_title` VARCHAR(600) NOT NULL AFTER `author_id`, ADD `author_seo_desc` VARCHAR(600) NOT NULL AFTER `author_seo_title`, ADD `author_seo_keys` VARCHAR(600) NOT NULL AFTER `author_seo_desc`;") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD `quote_seo_title` VARCHAR(600) NOT NULL AFTER `quote_id`, ADD `quote_seo_desc` VARCHAR(600) NOT NULL AFTER `quote_seo_title`, ADD `quote_seo_keys` VARCHAR(600) NOT NULL AFTER `quote_seo_desc`;") ;
    $Maqola->query("ALTER TABLE `maqola_articles` ADD `article_seo_title` VARCHAR(600) NOT NULL AFTER `article_id`, ADD `article_seo_desc` VARCHAR(600) NOT NULL AFTER `article_seo_title`, ADD `article_seo_keys` VARCHAR(600) NOT NULL AFTER `article_seo_desc`;") ;
}



$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_users` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) NOT NULL,
  `user_fullname` varchar(250) NOT NULL,
  `user_address` mediumtext NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_pass` varchar(32) NOT NULL,
  `user_mobile` varchar(30) NOT NULL,
  `user_country` varchar(250) NOT NULL,
  `user_photo` varchar(250) NOT NULL,
  `user_lastip` varchar(250) NOT NULL,
  `user_time` int(10) NOT NULL,
  `user_lastvisit` int(10) NOT NULL,
  `user_role` int(10) NOT NULL,
  `user_permissions` longtext NOT NULL,
  `user_status` int(10) NOT NULL,
  `user_code` varchar(30) NOT NULL,
  `user_notes` mediumtext NOT NULL,
  `section_id` int(10) NOT NULL,
  `notifications_time` int(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;");

$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_users_quotes` (
  `quote_id` int(10) NOT NULL AUTO_INCREMENT,
  `quote_content` mediumtext NOT NULL,
  `quote_note` mediumtext NOT NULL,
  `quote_date` varchar(250) NOT NULL,
  `quote_image` varchar(250) NOT NULL,
  `quote_featured` int(10) NOT NULL,
  `quote_time` int(10) NOT NULL,
  `quote_views` int(10) NOT NULL,
  `quote_source` varchar(250) NOT NULL,
  `quote_author` varchar(250) NOT NULL,
  `category_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`quote_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;



$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_settings` LIKE 'default_user_role';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `default_user_role` int(10) NOT NULL AFTER `site_perpage`;") ;
}



$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_users` LIKE 'user_views';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_users` ADD `user_views` int(10) NOT NULL AFTER `notifications_time`;") ;
    $Maqola->query("ALTER TABLE `maqola_users` ADD `user_count` int(10) NOT NULL AFTER `user_views`;") ;
}


$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_users` LIKE 'user_likes';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_users` ADD `user_likes` int(10) NOT NULL AFTER `user_count`;") ;
    $Maqola->query("ALTER TABLE `maqola_quotes` ADD `quote_likes` int(10) NOT NULL AFTER `quote_views`;") ;
    $Maqola->query("ALTER TABLE `maqola_users_quotes` ADD `quote_likes` int(10) NOT NULL AFTER `quote_views`;") ;
}


$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_settings` LIKE 'facebook_login_active';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `facebook_login_active` int(10) NOT NULL AFTER `site_perpage`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `facebook_login_appid` varchar(250) NOT NULL AFTER `facebook_login_active`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `facebook_login_appsecret` varchar(250) NOT NULL AFTER `facebook_login_appid`;") ;
    $Maqola->query("ALTER TABLE `maqola_users` ADD `facebook_login` varchar(500) NOT NULL AFTER `user_views`;") ;
}



$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_settings` LIKE 'twitter_login_active';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `twitter_login_active` int(10) NOT NULL AFTER `site_perpage`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `twitter_login_appid` varchar(250) NOT NULL AFTER `twitter_login_active`;") ;
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `twitter_login_appsecret` varchar(250) NOT NULL AFTER `twitter_login_appid`;") ;
    $Maqola->query("ALTER TABLE `maqola_users` ADD `twitter_login` varchar(500) NOT NULL AFTER `user_views`;") ;
    $Maqola->query( "UPDATE " . PREFIX_DB . "users_quotes SET quote_likes=0 ;" );
    $Maqola->query( "UPDATE " . PREFIX_DB . "users SET user_likes=0 ;" );
}


$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_likes` (
  `like_id` int(10) NOT NULL AUTO_INCREMENT,
  `like_time` int(10) NOT NULL,
  `like_ip` varchar(250) NOT NULL,
  `item_user_id` int(10) NOT NULL,
  `item_type` varchar(250) NOT NULL,
  `item_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  PRIMARY KEY (`like_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;



$Maqola->query("CREATE TABLE IF NOT EXISTS `maqola_pages` (
  `page_id` int(10) NOT NULL AUTO_INCREMENT,
  `page_seo_title` varchar(600) NOT NULL,
  `page_seo_desc` varchar(600) NOT NULL,
  `page_seo_keys` varchar(600) NOT NULL,
  `page_name` varchar(250) NOT NULL,
  `page_content` mediumtext NOT NULL,
  `page_desc` varchar(250) NOT NULL,
  `page_image` varchar(250) NOT NULL,
  `page_time` int(10) NOT NULL,
  `page_views` int(10) NOT NULL,
  `page_count` int(10) NOT NULL,
  `page_notes` mediumtext NOT NULL,
  `moderator_id` int(10) NOT NULL,
  PRIMARY KEY (`page_id`),
  KEY `page_id` (`page_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;") ;



$sql_data = $Maqola->query("SHOW COLUMNS FROM `maqola_settings` LIKE 'user_ranks';") ;
if($Maqola->rows($sql_data) == 0) {
    $Maqola->query("ALTER TABLE `maqola_settings` ADD `user_ranks` mediumtext NOT NULL AFTER `site_perpage`;") ;
    $Maqola->query("ALTER TABLE `maqola_users` ADD `user_rank` varchar(250) NOT NULL AFTER `user_count`;") ;
    $Maqola->query("ALTER TABLE `maqola_users` ADD `user_about` varchar(250) NOT NULL AFTER `user_rank`;") ;
}


$Maqola->go_to('./index.php');


?>