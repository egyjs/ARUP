<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */

    date_default_timezone_set("Asia/Riyadh");
    define('__Maqola__','ok');
    define('SYSTEM_DIR','../system/');
    define('CACHE_DIR',SYSTEM_DIR . 'cache/');
    define('STYLES_DIR','../styles/');
    define('TPL_DIR','admin');
    define('DATA_DIR','content');
	
    include SYSTEM_DIR . "functions.php";
    include SYSTEM_DIR . "config.php";
    include SYSTEM_DIR . "class_pages.php";
    include SYSTEM_DIR . "class_moderators.php";
    include SYSTEM_DIR . "class_users.php";
	
    $settings = $Maqola->select(array('id'=>1),'settings');
	$settings['version']      = $Maqola->version;
	$settings['admin_url']    = $settings['site_url']. ADMIN_DIR .'/' ;
	$settings['style_folder'] = STYLES_DIR ; 
	$settings['style_url']    = $settings['style_folder'] ;	
	$settings['data_folder']  = '../'.DATA_DIR.'/' ; 
	$settings['data_url']     = $settings['site_url']. DATA_DIR .'/' ;

    include SYSTEM_DIR . "lang/lang-ar.php";
	$Maqola->lang = $lang['id'] ;
	
	$token    = $Maqola->token;
	$users    = new users();
	$moderators    = new moderators();

	if($moderators->is_login()) {
        $moderatorinfo = $moderators->moderatorinfo ;
        $settings['is_moderator'] = true;
        $moderatorinfo['job_title'] = fetch_job_title($moderatorinfo);
		if($moderatorinfo['moderator_role'] == 1) {
            $settings['is_webmaster'] = true;
			$moderatorinfo['moderator_permissions'] = explode(',','settings,moderators,stats,categories,authors,sources,quotes,articles');
        } else {
            $settings['is_webmaster'] = false;
			$moderatorinfo['moderator_permissions'] = explode(',','categories,authors,sources,quotes,articles');
        }		
    } else {
        $moderatorinfo = array();
        $settings['is_moderator'] = false;
		$moderatorinfo['moderator_permissions'] = array();
    }
	
	if(!$moderatorinfo['moderator_id']){
		if($_POST['do'] == 'login' and $Maqola->is_valid_token() and $moderators->login($_POST)){
			$Maqola->go_to('index.php');
		} elseif ($_POST['do'] == 'login') {
			$show_error = true ;
		} else {
			$show_error = false ;
		}
		include $Maqola->tpl('login') ;
		exit;
	} elseif($_GET['do'] == 'logout') {
		$moderators->logout();
		$Maqola->go_to('index.php');
		exit;	
	}
	

	$caches = array();
	$caches['moderators_list'] = get_moderators_list();
	$caches['users_list'] = get_users_list();
	
	
?>