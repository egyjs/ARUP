<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','quotes');

	if(!$moderators->has_permission('quotes')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.quote_note LIKE '%$search%' 
									  OR A.quote_date 	 LIKE '%$search%'
									  OR A.quote_content 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['category_id'])){
				$hook_sql .= " AND (A.category_id = '".intval($_REQUEST['category_id'])."' OR A.category_ids LIKE '%:".intval($_REQUEST['category_id']).":%') " ;
				$params['category_id'] = intval($_REQUEST['category_id']) ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['author_id'])){
				$hook_sql .= " AND (A.author_id = '".intval($_REQUEST['author_id'])."' OR A.author_ids LIKE '%:".intval($_REQUEST['author_id']).":%') " ;
				$params['author_id'] = intval($_REQUEST['author_id']) ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['source_id'])){
				$hook_sql .= " AND (A.source_id = '".intval($_REQUEST['source_id'])."' OR A.source_ids LIKE '%:".intval($_REQUEST['source_id']).":%') " ;
				$params['source_id'] = intval($_REQUEST['source_id']) ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'quotes.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'quotes.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.quote_id", PREFIX_DB . "quotes A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.quote_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*,B.category_name
			FROM " . PREFIX_DB . "quotes A
			LEFT JOIN  " . PREFIX_DB . "categories B ON  B.category_id=A.category_id
			$hook_sql $sql_order $sql_limit ;" );
			$quotes_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$quotes_list [] = $data ;
			}
		
			include $Maqola->tpl('quotes') ;
		break;
		
		case 'addquote':
			$is_editquote = false ;			
			$quotedata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['quote_content'])) < 3){
					$Maqola->msg($lang['quote_content_wrong']);
				}

				
				$data   = array();
				$data['category_id'] = intval($_POST['category_id_default']);
				$data['author_id'] = intval($_POST['author_id_default']);
				$data['source_id'] = intval($_POST['source_id_default']);
				$data['category_ids'] = pre_quote_ids($_POST['category_ids']);
				$data['author_ids'] = pre_quote_ids($_POST['author_ids']);
				$data['source_ids'] = pre_quote_ids($_POST['source_ids']);
				$data['quote_content'] = dataforsql($_POST['quote_content'],true);
				$data['quote_note'] = dataforsql(trim($_POST['quote_note']),true) ;
				$data['quote_date'] = dataforsql(trim($_POST['quote_date']),true) ;
				$data['quote_featured'] = intval($_POST['quote_featured']);
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['quote_time'] = time();
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;


                $quote_image = $Maqola->upload_file($_FILES['image'],'quotes');
				if(!empty($quote_image)){
					$data['quote_image'] = $quote_image;
				}
				
				
				$quote_id = $Maqola->insert($data,'quotes');
				
				update_quote_count($data);
				
				$Maqola->msg($lang['quotes_add_successfully'],'quotes.php');
				exit;
			} 
		
			include $Maqola->tpl('quotes_add') ;
		break;
		
		case 'editquote':
			$is_editquote = true ;
			
			$quotedata = $Maqola->select(array('quote_id'=>intval($_GET['id'])),'quotes');
			
			if(!$quotedata['quote_id']){
				$Maqola->go_to('quotes.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $quotedata['moderator_id']){
					$Maqola->go_to('quotes.php');
				}
			}
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['quote_content'])) < 3){
					$Maqola->msg($lang['quote_content_wrong']);
				}
				
				$data   = array();
				$data['category_id'] = intval($_POST['category_id_default']);
				$data['author_id'] = intval($_POST['author_id_default']);
				$data['source_id'] = intval($_POST['source_id_default']);
				$data['category_ids'] = pre_quote_ids($_POST['category_ids']);
				$data['author_ids'] = pre_quote_ids($_POST['author_ids']);
				$data['source_ids'] = pre_quote_ids($_POST['source_ids']);
				$data['quote_content'] = dataforsql($_POST['quote_content'],true);
				$data['quote_note'] = dataforsql(trim($_POST['quote_note']),true) ;
				$data['quote_date'] = dataforsql(trim($_POST['quote_date']),true) ;
				$data['quote_featured'] = intval($_POST['quote_featured']);
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;

                $quote_image = $Maqola->upload_file($_FILES['image'],'quotes');
				if(!empty($quote_image)){
					$data['quote_image'] = $quote_image;
				}
				
				$Maqola->update($data,$quotedata['quote_id'],'quotes','quote_id');
				
				update_quote_count($data);
				update_quote_count($quotedata);
				
				
				$Maqola->msg($lang['quotes_edit_successfully'],'quotes.php');
				exit;
			} 
		
			include $Maqola->tpl('quotes_add') ;
		break;
	
		case 'delquote':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$quotedata = $Maqola->select(array('quote_id'=>intval($_GET['id'])),'quotes');
			if(!$quotedata['quote_id']){
				$Maqola->go_to('quotes.php');
			}
			
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $quotedata['moderator_id']){
					$Maqola->go_to('quotes.php');
				}
			}
			
			
			update_quote_count($quotedata);
			
			$Maqola->delete(array('quote_id'=>$quotedata['quote_id']),'quotes');
			$Maqola->go_to('quotes.php');
		break;
		
		
		case 'get-options':
		
			$options = '' ;
			if(trim($_POST['filter']) != ''){
				if($_POST['data_id'] == 'category_id'){
					$categories = get_categories_list($_POST['filter']);
					$options = '<option value="0">'.$lang['category_not_selected'].'</option>' ;
					foreach($categories as $category_id => $category_name){
						$options .= '<option value="'.$category_id.'">'.$category_name.'</option>' ;
					}
				}elseif($_POST['data_id'] == 'author_id'){
					$categories = get_authors_list($_POST['filter']);
					$options = '<option value="0">'.$lang['author_not_selected'].'</option>' ;
					foreach($categories as $author_id => $author_name){
						$options .= '<option value="'.$author_id.'">'.$author_name.'</option>' ;
					}
				}elseif($_POST['data_id'] == 'source_id'){
					$categories = get_sources_list($_POST['filter']);
					$options = '<option value="0">'.$lang['source_not_selected'].'</option>' ;
					foreach($categories as $source_id => $source_name){
						$options .= '<option value="'.$source_id.'">'.$source_name.'</option>' ;
					}
				}
			}
			
			header('Content-Type: application/json');
			echo json_encode(array('status'=>true, 'options'=>$options));
			exit;
		break;
		
		
	}
 
?>