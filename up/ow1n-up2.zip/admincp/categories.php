<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','categories');

	if(!$moderators->has_permission('categories')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.category_name LIKE '%$search%' 
									  OR A.category_desc 	 LIKE '%$search%'
									  OR A.category_notes 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'categories.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'categories.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.category_id", PREFIX_DB . "categories A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.category_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*
			FROM " . PREFIX_DB . "categories A
			$hook_sql $sql_order $sql_limit ;" );
			$categories_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$categories_list [] = $data ;
			}
		
			include $Maqola->tpl('categories') ;
		break;
		
		case 'addcategory':
			$is_editcategory = false ;			
			$categorydata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['category_name'])) < 3){
					$Maqola->msg($lang['category_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['category_desc'])) < 3){
					$Maqola->msg($lang['category_desc_wrong']);
				}

				
				$data   = array();
				$data['category_name'] = dataforsql(trim($_POST['category_name']),true) ;
				$data['category_desc'] = dataforsql(trim($_POST['category_desc']),true) ;
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['category_time'] = time();
				
				$category_image = $Maqola->upload_file($_FILES['image'],'categories');
				if(!empty($category_image)){
					$data['category_image'] = $category_image;
				}
				
				$category_id = $Maqola->insert($data,'categories');
				$Maqola->msg($lang['categories_add_successfully'],'categories.php');
				exit;
			} 
		
			include $Maqola->tpl('categories_add') ;
		break;
		
		case 'editcategory':
			$is_editcategory = true ;
			
			$categorydata = $Maqola->select(array('category_id'=>intval($_GET['id'])),'categories');
			
			if(!$categorydata['category_id']){
				$Maqola->go_to('categories.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $categorydata['moderator_id']){
					$Maqola->go_to('categories.php');
				}
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['category_name'])) < 3){
					$Maqola->msg($lang['category_name_wrong']);
				}
				
				
				if(mb_strlen(trim($_POST['category_desc'])) < 3){
					$Maqola->msg($lang['category_desc_wrong']);
				}

				
				$data   = array();
				$data['category_name'] = dataforsql(trim($_POST['category_name']),true) ;
				$data['category_desc'] = dataforsql(trim($_POST['category_desc']),true) ;
				
				$category_image = $Maqola->upload_file($_FILES['image'],'categories');
				if(!empty($category_image)){
					$data['category_image'] = $category_image;
				}
				
				$Maqola->update($data,$categorydata['category_id'],'categories','category_id');
				$Maqola->msg($lang['categories_edit_successfully'],'categories.php');
				exit;
			} 
		
			include $Maqola->tpl('categories_add') ;
		break;
	
		case 'delcategory':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$categorydata = $Maqola->select(array('category_id'=>intval($_GET['id'])),'categories');
			if(!$categorydata['category_id']){
				$Maqola->go_to('categories.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $categorydata['moderator_id']){
					$Maqola->go_to('categories.php');
				}
			}
			
			$Maqola->delete(array('category_id'=>$categorydata['category_id']),'categories');
			$Maqola->go_to('categories.php');
		break;
		
		
		
	}
 
?>