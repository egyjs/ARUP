<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','sources');

	if(!$moderators->has_permission('sources')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.source_name LIKE '%$search%' 
									  OR A.source_desc 	 LIKE '%$search%'
									  OR A.source_notes 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'sources.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'sources.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.source_id", PREFIX_DB . "sources A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.source_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*
			FROM " . PREFIX_DB . "sources A
			$hook_sql $sql_order $sql_limit ;" );
			$sources_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$sources_list [] = $data ;
			}
		
			include $Maqola->tpl('sources') ;
		break;
		
		case 'addsource':
			$is_editsource = false ;			
			$sourcedata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['source_name'])) < 3){
					$Maqola->msg($lang['source_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['source_desc'])) < 3){
					$Maqola->msg($lang['source_desc_wrong']);
				}

				
				$data   = array();
				$data['source_seo_title'] = dataforsql(trim($_POST['source_seo_title']),true) ;
				$data['source_seo_desc'] = dataforsql(trim($_POST['source_seo_desc']),true) ;
				$data['source_seo_keys'] = dataforsql(trim($_POST['source_seo_keys']),true) ;
				$data['source_name'] = dataforsql(trim($_POST['source_name']),true) ;
				$data['source_desc'] = dataforsql(trim($_POST['source_desc']),true) ;
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['source_time'] = time();
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;


                $source_image = $Maqola->upload_file($_FILES['image'],'sources');
				if(!empty($source_image)){
					$data['source_image'] = $source_image;
				}
				
				$source_id = $Maqola->insert($data,'sources');
				$Maqola->msg($lang['sources_add_successfully'],'sources.php');
				exit;
			} 
		
			include $Maqola->tpl('sources_add') ;
		break;
		
		case 'editsource':
			$is_editsource = true ;
			
			$sourcedata = $Maqola->select(array('source_id'=>intval($_GET['id'])),'sources');
			
			if(!$sourcedata['source_id']){
				$Maqola->go_to('sources.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $sourcedata['moderator_id']){
					$Maqola->go_to('sources.php');
				}
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['source_name'])) < 3){
					$Maqola->msg($lang['source_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['source_desc'])) < 3){
					$Maqola->msg($lang['source_desc_wrong']);
				}
				
				$data   = array();
				$data['source_seo_title'] = dataforsql(trim($_POST['source_seo_title']),true) ;
				$data['source_seo_desc'] = dataforsql(trim($_POST['source_seo_desc']),true) ;
				$data['source_seo_keys'] = dataforsql(trim($_POST['source_seo_keys']),true) ;
				$data['source_name'] = dataforsql(trim($_POST['source_name']),true) ;
				$data['source_desc'] = dataforsql(trim($_POST['source_desc']),true) ;
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;


                $source_image = $Maqola->upload_file($_FILES['image'],'sources');
				if(!empty($source_image)){
					$data['source_image'] = $source_image;
				}
				
				$Maqola->update($data,$sourcedata['source_id'],'sources','source_id');
				$Maqola->msg($lang['sources_edit_successfully'],'sources.php');
				exit;
			} 
		
			include $Maqola->tpl('sources_add') ;
		break;
	
		case 'delsource':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$sourcedata = $Maqola->select(array('source_id'=>intval($_GET['id'])),'sources');
			if(!$sourcedata['source_id']){
				$Maqola->go_to('sources.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $sourcedata['moderator_id']){
					$Maqola->go_to('sources.php');
				}
			}
			
			$Maqola->delete(array('source_id'=>$sourcedata['source_id']),'sources');
			$Maqola->go_to('sources.php');
		break;
		
		
		
	}
 
?>