<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */

date_default_timezone_set("Asia/Riyadh");
define('__Maqola__','ok');
include "../system/functions.php";
include "../system/config.php";


$Maqola->query("ALTER TABLE `maqola_sources` ADD `canonical`  varchar(600) NULL AFTER `source_views`;") ;
$Maqola->query("ALTER TABLE `maqola_authors` ADD `canonical` varchar(600) NULL AFTER `author_notes`;") ;
$Maqola->query("ALTER TABLE `maqola_quotes` ADD `canonical` varchar(600) NULL AFTER `quote_views`;") ;
$Maqola->query("ALTER TABLE `maqola_articles` ADD `canonical` varchar(600) NULL AFTER `article_seo_keys`;") ;

$Maqola->query("ALTER TABLE `maqola_articles` ADD `article_ids` varchar(500) NULL AFTER `article_desc`;") ;


$Maqola->go_to('./index.php');

