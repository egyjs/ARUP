<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');

	switch ($_GET['do']){
	
		default:
			$_GET['do'] = 'home' ;
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				$data   = array();
				$data['moderator_notes'] = dataforsql(trim($_POST['moderator_notes']),true) ;
				$Maqola->update($data,$moderatorinfo['moderator_id'],'moderators','moderator_id');
				$Maqola->msg($lang['changes_saved_successfully'],'index.php');
			}
			
			include $Maqola->tpl('home') ;
		break;
		
		case 'settings':
			if(!$moderators->has_permission('settings')){
				$Maqola->msg($lang['no_permissions'],'index.php');
				exit;
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['site_name'])) < 3){
					$Maqola->msg($lang['site_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['site_desc'])) < 3){
					$Maqola->msg($lang['site_desc_wrong']);
				}
				
				if(mb_strlen(trim($_POST['site_url'])) < 3 or substr(trim($_POST['site_url']),0,4) != 'http'){
					$Maqola->msg($lang['site_url_wrong']);
				}
				
				
				$data   = array();
				$data['site_name'] = dataforsql(trim($_POST['site_name']),true) ;
				$data['site_desc'] = dataforsql(trim($_POST['site_desc']),true) ;
				$data['site_url'] = dataforsql(trim($_POST['site_url']),true) ;
				$data['site_email'] = dataforsql(trim($_POST['site_email']),true) ;
				$data['site_terms'] = dataforsql(trim($_POST['site_terms']),true) ;
				$data['site_facebook'] = dataforsql(trim($_POST['site_facebook']),true) ;
				$data['site_twitter'] = dataforsql(trim($_POST['site_twitter']),true) ;
				$data['site_instagram'] = dataforsql(trim($_POST['site_instagram']),true) ;
				$data['site_youtube'] = dataforsql(trim($_POST['site_youtube']),true) ;
				$data['site_snapchat'] = dataforsql(trim($_POST['site_snapchat']),true) ;
				$data['site_telegram'] = dataforsql(trim($_POST['site_telegram']),true) ;
				$data['site_google'] = dataforsql(trim($_POST['site_google']),true) ;
				$data['site_redirect_old'] = intval($_POST['site_redirect_old']) ;
				$data['default_user_role'] = intval($_POST['default_user_role']) ;
				
				$data['facebook_login_active'] = intval($_POST['facebook_login_active']) ;
				$data['facebook_login_appid'] = dataforsql(trim($_POST['facebook_login_appid']),true) ;
				$data['facebook_login_appsecret'] = dataforsql(trim($_POST['facebook_login_appsecret']),true) ;
				
				$data['twitter_login_active'] = intval($_POST['twitter_login_active']) ;
				$data['twitter_login_appid'] = dataforsql(trim($_POST['twitter_login_appid']),true) ;
				$data['twitter_login_appsecret'] = dataforsql(trim($_POST['twitter_login_appsecret']),true) ;
				
				$data['site_seo_title'] = dataforsql(trim($_POST['site_seo_title']),true) ;
				$data['site_seo_desc'] = dataforsql(trim($_POST['site_seo_desc']),true) ;
				$data['site_seo_keys'] = dataforsql(trim($_POST['site_seo_keys']),true) ;
	
				$data['t1_header_title'] = dataforsql(trim($_POST['t1_header_title']),true) ;
				$data['t1_header_logo'] = dataforsql(trim($_POST['t1_header_logo']),true) ;
				$data['t1_bg_color'] = dataforsql(trim($_POST['t1_bg_color']),true) ;
				$data['t1_font_color'] = dataforsql(trim($_POST['t1_font_color']),true) ;
				
				if($_POST['t1_img_logo_delete']){
					$data['t1_img_logo'] = '';
				}else{
					$t1_img_logo = $Maqola->upload_file($_FILES['t1_img_logo']);
					if(!empty($t1_img_logo)){
						$data['t1_img_logo'] = $t1_img_logo;
					}
				}
				
				
				if($_POST['t1_img_bg_delete']){
					$data['t1_img_bg'] = '';
				}else{
					$t1_img_bg = $Maqola->upload_file($_FILES['t1_img_bg']);
					if(!empty($t1_img_bg)){
						$data['t1_img_bg'] = $t1_img_bg;
					}
				}
				
				$data['user_ranks'] = json_encode($_POST['user_ranks']) ;
				$Maqola->update($data,1,'settings','id');
				$Maqola->msg($lang['changes_saved_successfully'],'index.php?do=settings');
				exit;
			} 
			
			$settingsdata = $Maqola->select(array('id'=>1),'settings');
			$user_ranks = json_decode($settingsdata['user_ranks'],true) ;
			include $Maqola->tpl('settings') ;
		break;
		
		case 'profile':

			if($_POST['save'] == 'true' and $Maqola->is_valid_token()){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if($moderators->moderator_pass($_POST['currentpass']) != $moderatorinfo['moderator_pass']){
					$Maqola->msg($lang['currentpass_wrong']);
				}
				
				if(!is_mail($_POST['moderator_email'])){
					$Maqola->msg($lang['moderator_email_wrong']);
				}
				
				if(mb_strlen(trim($_POST['moderator_name'])) < 3){
					$Maqola->msg($lang['username_wrong']);
				}
				
				if(!empty($_POST['newpass'])  and mb_strlen(trim($_POST['newpass'])) < 6){
					$Maqola->msg($lang['userpass_wrong']);
				}
				
				$data   = array();
				$data['moderator_name'] = $moderators->moderator_name(trim($_POST['moderator_name'])) ;
				$data['moderator_email'] = dataforsql(trim($_POST['moderator_email']),true) ;
				if(!empty($_POST['newpass'])){
					if(mb_strlen(trim($_POST['newpass'])) < 6){
						$Maqola->msg($lang['moderator_pass_wrong']);
					}
					$data['moderator_pass'] = $moderators->moderator_pass(trim($_POST['newpass'])) ;
				}
				
				
				$check = $Maqola->select(array('moderator_name'=>$data['moderator_name']),'moderators','LIMIT 1',' AND moderator_id <> '.$moderatorinfo['moderator_id']);
				if($check){
					$Maqola->msg($lang['moderator_name_already_registered']);
				}
				
				$check = $Maqola->select(array('moderator_email'=>$data['moderator_email']),'moderators','LIMIT 1',' AND moderator_id <> '.$moderatorinfo['moderator_id']);
				if($check){
					$Maqola->msg($lang['moderator_email_already_registered']);
				}
				
				$Maqola->update($data,$moderatorinfo['moderator_id'],'moderators','moderator_id');
				$_POST['moderator_pass'] = (!empty($_POST['newpass'])) ? trim($_POST['newpass']) : trim($_POST['currentpass']) ;
				$moderators->login($_POST);
				$Maqola->msg($lang['changes_saved_successfully'],'index.php?do=profile');
				exit;
			} 
		
			include $Maqola->tpl('profile') ;
		break;
		
		case 'stats':
			if(!$moderators->has_permission('stats')){
				$Maqola->msg($lang['no_permissions'],'index.php');
				exit;
			}
			
			

			$stats_list    = array();
			$stats_list [] = array($lang['moderators_count'],$Maqola->query_stats('count(*)',array(),'moderators'));
			$stats_list [] = array($lang['users_count'],$Maqola->query_stats('count(*)',array(),'users'));
			$stats_list [] = array($lang['categories_count'],$Maqola->query_stats('count(*)',array(),'categories'));
			$stats_list [] = array($lang['sources_count'],$Maqola->query_stats('count(*)',array(),'sources'));
			$stats_list [] = array($lang['authors_count'],$Maqola->query_stats('count(*)',array(),'authors'));
			$stats_list [] = array($lang['quotes_count'],$Maqola->query_stats('count(*)',array(),'quotes'));
			$stats_list [] = array($lang['articles_count'],$Maqola->query_stats('count(*)',array(),'articles'));
			$stats_list [] = array($lang['pages_count'],$Maqola->query_stats('count(*)',array(),'pages'));
			$stats_list [] = array($lang['users_quotes_count'],$Maqola->query_stats('count(*)',array(),'users_quotes'));

			
			include $Maqola->tpl('stats') ;
		break;
		
	}
 
?>