<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','users');

	if(!$moderators->has_permission('users')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.user_name LIKE '%$search%' 
									  OR A.user_email LIKE '%$search%'
									  OR A.user_country  LIKE '%$search%'
									  OR A.user_fullname LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			
			if(count($params)){
				$baseURL = 'users.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'users.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.user_id", PREFIX_DB . "users A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.user_id DESC " ;

			$sql = $Maqola->query( "SELECT A.*,
			(SELECT  COUNT(*) FROM " . PREFIX_DB . "users_quotes C WHERE C.user_id=A.user_id ) AS quotes_count 
			FROM " . PREFIX_DB . "users A
			$hook_sql $sql_order $sql_limit ;" );
			$users_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$users_list [] = $data ;
			}
		
			include $Maqola->tpl('users') ;
		break;
	
		
		case 'adduser':
			$is_edituser = false ;			
			$userdata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				
				if(mb_strlen(trim($_POST['user_fullname'])) < 3){
					$Maqola->msg($lang['user_fullname_wrong']);
				}
				
				if(!is_mail($_POST['user_email'])){
					$Maqola->msg($lang['user_email_wrong']);
				}
				
				
				if(mb_strlen(trim($_POST['user_name'])) < 3){
					$Maqola->msg($lang['user_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['user_pass'])) < 6){
					$Maqola->msg($lang['user_pass_wrong']);
				}
					
				if(!intval($_POST['user_role'])){
					$Maqola->msg($lang['user_role_select']);
				}
				
				
				$data   = array();
				$data['user_fullname'] = dataforsql(trim($_POST['user_fullname']),true) ;
				$data['user_email'] = dataforsql(trim($_POST['user_email']),true) ;
				$data['user_name'] = $users->user_name(trim($_POST['user_name'])) ;
				$data['user_country'] = dataforsql(trim($_POST['user_country']),true) ;
				$data['user_rank'] = dataforsql(trim($_POST['user_rank']),true) ;
				$data['user_about'] = dataforsql(trim($_POST['user_about']),true) ;
				$data['user_role'] = intval($_POST['user_role']);
				$data['user_pass'] = $users->user_pass(trim($_POST['user_pass'])) ;
				$data['user_time'] = time();
				
				$check = $Maqola->select(array('user_name'=>$data['user_name']),'users','LIMIT 1',' AND 1=1 ');
				if($check){
					$Maqola->msg($lang['user_name_already_registered']);
				}
				
				$check = $Maqola->select(array('user_email'=>$data['user_email']),'users','LIMIT 1',' AND 1=1 ');
				if($check){
					$Maqola->msg($lang['user_email_already_registered']);
				}
				
				$user_id = $Maqola->insert($data,'users');
				$Maqola->msg($lang['users_add_successfully'],'users.php');
				exit;
			} 
		
			include $Maqola->tpl('users_add') ;
		break;
		
		case 'edituser':
			$is_edituser = true ;
			
			$userdata = $Maqola->select(array('user_id'=>intval($_GET['id'])),'users');
			
			if(!$userdata['user_id']){
				$Maqola->go_to('users.php');
			}
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				
				if(mb_strlen(trim($_POST['user_fullname'])) < 3){
					$Maqola->msg($lang['user_fullname_wrong']);
				}
				
				
				if(!is_mail($_POST['user_email'])){
					$Maqola->msg($lang['user_email_wrong']);
				}
				
				
				if(mb_strlen(trim($_POST['user_name'])) < 3){
					$Maqola->msg($lang['user_name_wrong']);
				}
					
				if(!intval($_POST['user_role'])){
					$Maqola->msg($lang['user_role_select']);
				}
				
				
				
				$data   = array();
				$data['user_fullname'] = dataforsql(trim($_POST['user_fullname']),true) ;
				$data['user_email'] = dataforsql(trim($_POST['user_email']),true) ;
				$data['user_name'] = $users->user_name(trim($_POST['user_name'])) ;
				$data['user_country'] = dataforsql(trim($_POST['user_country']),true) ;
				$data['user_rank'] = dataforsql(trim($_POST['user_rank']),true) ;
				$data['user_about'] = dataforsql(trim($_POST['user_about']),true) ;
				$data['user_role'] = intval($_POST['user_role']);
				if(!empty($_POST['user_pass'])){
					if(mb_strlen(trim($_POST['user_pass'])) < 6){
						$Maqola->msg($lang['user_pass_wrong']);
					}
					$data['user_pass'] = $users->user_pass(trim($_POST['user_pass'])) ;
				}
				
				if($userdata['user_id'] == 1){
					unset($data['user_role']);
				}
				
				$check = $Maqola->select(array('user_name'=>$data['user_name']),'users','LIMIT 1',' AND user_id <> '.$userdata['user_id']);
				if($check){
					$Maqola->msg($lang['user_name_already_registered']);
				}
				
				if(is_mail($data['user_email'])){
					$check = $Maqola->select(array('user_email'=>$data['user_email']),'users','LIMIT 1',' AND user_id <> '.$userdata['user_id']);
					if($check){
						$Maqola->msg($lang['user_email_already_registered']);
					}
				}
				
				$Maqola->update($data,$userdata['user_id'],'users','user_id');
				$Maqola->msg($lang['users_edit_successfully'],'users.php');
				exit;
			} 
			
			$userdata['user_permissions'] = explode(',',$userdata['user_permissions']);
			include $Maqola->tpl('users_add') ;
		break;
	
		case 'deluser':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
				
			$userdata = $Maqola->select(array('user_id'=>intval($_GET['id'])),'users');
			if(!$userdata['user_id']){
				$Maqola->go_to('users.php');
			}
			
			$Maqola->delete(array('user_id'=>$userdata['user_id']),'users');
			$Maqola->go_to('users.php');
		break;
		
		
		case 'quotes':
			define('NAVBAR_ACTIVE_SKIP',true);
			define('PARENT_NAVBAR_ACTIVE','do=quotes');
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.quote_note LIKE '%$search%' 
									  OR A.quote_date 	 LIKE '%$search%'
									  OR A.quote_content 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['category_id'])){
				$hook_sql .= " AND (A.category_id = '".intval($_REQUEST['category_id'])."' ) " ;
				$params['category_id'] = intval($_REQUEST['category_id']) ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['user_id'])){
				$hook_sql .= " AND (A.user_id = '".intval($_REQUEST['user_id'])."' ) " ;
				$params['user_id'] = intval($_REQUEST['user_id']) ;
				$is_mode_search = true ;
			}
			
			
			if(count($params)){
				$baseURL = 'users.php?do=quotes&'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'users.php?do=quotes*&page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.quote_id", PREFIX_DB . "users_quotes A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.quote_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*,B.category_name
			FROM " . PREFIX_DB . "users_quotes A
			LEFT JOIN  " . PREFIX_DB . "categories B ON  B.category_id=A.category_id
			$hook_sql $sql_order $sql_limit ;" );
			$quotes_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$quotes_list [] = $data ;
			}
		
			include $Maqola->tpl('users_quotes') ;
		break;
		
		case 'addquote':
			$Maqola->go_to('users.php?do=quotes');
			exit;
			define('NAVBAR_ACTIVE_SKIP',true);
			define('PARENT_NAVBAR_ACTIVE','do=quotes');
			
			$is_editquote = false ;			
			$quotedata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['quote_content'])) < 3){
					$Maqola->msg($lang['quote_content_wrong']);
				}

				
				$data   = array();
				$data['quote_content'] = dataforsql($_POST['quote_content'],true);
				$data['quote_author'] = dataforsql(trim($_POST['quote_author']),true) ;
				$data['quote_source'] = dataforsql(trim($_POST['quote_source']),true) ;
				$data['category_id'] = intval($_POST['category_id']);
				$data['quote_time'] = time();
				
				
				$quote_id = $Maqola->insert($data,'users_quotes');
				
				
				$Maqola->msg($lang['quotes_add_successfully'],'users.php?do=quotes');
				exit;
			} 
		
			include $Maqola->tpl('users_quotes_add') ;
		break;
		
		case 'editquote':
			define('NAVBAR_ACTIVE_SKIP',true);
			define('PARENT_NAVBAR_ACTIVE','do=quotes');
			
			$is_editquote = true ;
			
			$quotedata = $Maqola->select(array('quote_id'=>intval($_GET['id'])),'users_quotes');
			
			if(!$quotedata['quote_id']){
				$Maqola->go_to('users.php?do=quotes');
			}
			
			/* if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $quotedata['moderator_id']){
					$Maqola->go_to('users.php?do=quotes');
				}
			} */
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['quote_content'])) < 3){
					$Maqola->msg($lang['quote_content_wrong']);
				}
				
				$data   = array();
				$data['quote_content'] = dataforsql($_POST['quote_content'],true);
				$data['quote_author'] = dataforsql(trim($_POST['quote_author']),true) ;
				$data['quote_source'] = dataforsql(trim($_POST['quote_source']),true) ;
				$data['category_id'] = intval($_POST['category_id']);
				
				
				$Maqola->update($data,$quotedata['quote_id'],'users_quotes','quote_id');
				
				
				$Maqola->msg($lang['quotes_edit_successfully'],'users.php?do=quotes');
				exit;
			} 
		
			include $Maqola->tpl('users_quotes_add') ;
		break;
	
		case 'delquote':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$quotedata = $Maqola->select(array('quote_id'=>intval($_GET['id'])),'users_quotes');
			if(!$quotedata['quote_id']){
				$Maqola->go_to('users.php?do=quotes');
			}
			
			
		/* 	if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $quotedata['moderator_id']){
					$Maqola->go_to('users.php?do=quotes');
				}
			}
			 */
			
			$Maqola->delete(array('quote_id'=>$quotedata['quote_id']),'users_quotes');
			$Maqola->go_to('users.php?do=quotes');
		break;
		
	}
 
?>