<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','pages');

	if(!$moderators->has_permission('pages')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.page_name LIKE '%$search%' 
									  OR A.page_desc 	 LIKE '%$search%'
									  OR A.page_notes 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'pages.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'pages.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.page_id", PREFIX_DB . "pages A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.page_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*
			FROM " . PREFIX_DB . "pages A
			$hook_sql $sql_order $sql_limit ;" );
			$pages_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$pages_list [] = $data ;
			}
		
			include $Maqola->tpl('pages') ;
		break;
		
		case 'addpage':
			$is_editpage = false ;			
			$pagedata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['page_name'])) < 3){
					$Maqola->msg($lang['page_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['page_desc'])) < 3){
					$Maqola->msg($lang['page_desc_wrong']);
				}

				
				$data   = array();
				$data['page_seo_title'] = dataforsql(trim($_POST['page_seo_title']),true) ;
				$data['page_seo_desc'] = dataforsql(trim($_POST['page_seo_desc']),true) ;
				$data['page_seo_keys'] = dataforsql(trim($_POST['page_seo_keys']),true) ;
				$data['page_name'] = dataforsql(trim($_POST['page_name']),true) ;
				$data['page_desc'] = dataforsql(trim($_POST['page_desc']),true) ;
				$data['page_content'] = dataforsql(trim($_POST['page_content']),true) ;
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['page_time'] = time();
				
				$quotes_ids = explode("\r\n",trim($_POST['page_content']));
				$data['page_count'] = count($quotes_ids);
				
				$page_image = $Maqola->upload_file($_FILES['image'],'pages');
				if(!empty($page_image)){
					$data['page_image'] = $page_image;
				}
				
				$page_id = $Maqola->insert($data,'pages');
				$Maqola->msg($lang['pages_add_successfully'],'pages.php');
				exit;
			} 
		
			include $Maqola->tpl('pages_add') ;
		break;
		
		case 'editpage':
			$is_editpage = true ;
			
			$pagedata = $Maqola->select(array('page_id'=>intval($_GET['id'])),'pages');
			
			if(!$pagedata['page_id']){
				$Maqola->go_to('pages.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $pagedata['moderator_id']){
					$Maqola->go_to('pages.php');
				}
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['page_name'])) < 3){
					$Maqola->msg($lang['page_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['page_desc'])) < 3){
					$Maqola->msg($lang['page_desc_wrong']);
				}
				
				$data   = array();
				$data['page_seo_title'] = dataforsql(trim($_POST['page_seo_title']),true) ;
				$data['page_seo_desc'] = dataforsql(trim($_POST['page_seo_desc']),true) ;
				$data['page_seo_keys'] = dataforsql(trim($_POST['page_seo_keys']),true) ;
				$data['page_name'] = dataforsql(trim($_POST['page_name']),true) ;
				$data['page_desc'] = dataforsql(trim($_POST['page_desc']),true) ;
				$data['page_content'] = dataforsql(trim($_POST['page_content']),true) ;
				
				$quotes_ids = explode("\r\n",trim($_POST['page_content']));
				$data['page_count'] = count($quotes_ids);
				
				$page_image = $Maqola->upload_file($_FILES['image'],'pages');
				if(!empty($page_image)){
					$data['page_image'] = $page_image;
				}
				
				$Maqola->update($data,$pagedata['page_id'],'pages','page_id');
				$Maqola->msg($lang['pages_edit_successfully'],'pages.php');
				exit;
			} 
		
			include $Maqola->tpl('pages_add') ;
		break;
	
		case 'delpage':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$pagedata = $Maqola->select(array('page_id'=>intval($_GET['id'])),'pages');
			if(!$pagedata['page_id']){
				$Maqola->go_to('pages.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $pagedata['moderator_id']){
					$Maqola->go_to('pages.php');
				}
			}
			
			$Maqola->delete(array('page_id'=>$pagedata['page_id']),'pages');
			$Maqola->go_to('pages.php');
		break;
		
		
		
	}
 
?>