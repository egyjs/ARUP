<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','articles');

	if(!$moderators->has_permission('articles')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
				
				
				$parpage = 500 ;
				$hook_sql .= " AND (A.article_title LIKE '%$search%' 
									  OR A.article_desc 	 LIKE '%$search%'
									  OR A.article_content 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['category_id'])){
				$hook_sql .= " AND (A.category_id = '".intval($_REQUEST['category_id'])."' OR A.category_ids LIKE '%:".intval($_REQUEST['category_id']).":%') " ;
				$params['category_id'] = intval($_REQUEST['category_id']) ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['author_id'])){
				$hook_sql .= " AND (A.author_id = '".intval($_REQUEST['author_id'])."' OR A.author_ids LIKE '%:".intval($_REQUEST['author_id']).":%') " ;
				$params['author_id'] = intval($_REQUEST['author_id']) ;
				$is_mode_search = true ;
			}
			
			if(intval($_REQUEST['source_id'])){
				$hook_sql .= " AND (A.source_id = '".intval($_REQUEST['source_id'])."' OR A.source_ids LIKE '%:".intval($_REQUEST['source_id']).":%') " ;
				$params['source_id'] = intval($_REQUEST['source_id']) ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'articles.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'articles.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.article_id", PREFIX_DB . "articles A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.article_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*,B.category_name
			FROM " . PREFIX_DB . "articles A
			LEFT JOIN  " . PREFIX_DB . "categories B ON  B.category_id=A.category_id
			$hook_sql $sql_order $sql_limit ;" );
			$articles_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$articles_list [] = $data ;
			}
		
			include $Maqola->tpl('articles') ;
		break;
		
		case 'addarticle':
			$is_editarticle = false ;			
			$articledata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['article_title'])) < 3){
					$Maqola->msg($lang['article_title_wrong']);
				}

				
				$data   = array();
				$data['category_id'] = intval($_POST['category_id_default']);
				$data['author_id'] = intval($_POST['author_id_default']);
				$data['source_id'] = intval($_POST['source_id_default']);
                $data['category_ids'] = pre_article_ids($_POST['category_ids']);
                $data['article_ids'] = pre_article_ids($_POST['article_ids']);
				$data['author_ids'] = pre_article_ids($_POST['author_ids']);
				$data['source_ids'] = pre_article_ids($_POST['source_ids']);
                $data['article_title'] = dataforsql(trim($_POST['article_title']),true) ;
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;
				$data['article_desc'] = dataforsql(trim($_POST['article_desc']),true) ;
				$data['article_seo_keys'] = dataforsql(trim($_POST['article_seo_keys']),true) ;
				$data['article_content'] = dataforsql($_POST['article_content'],true);
				$data['article_featured'] = intval($_POST['article_featured']);
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['article_time'] = time();
				
				$article_image = $Maqola->upload_file($_FILES['image'],'articles');
				if(!empty($article_image)){
					$data['article_image'] = $article_image;
				}
				
				
				$article_id = $Maqola->insert($data,'articles');
				
				update_article_count($data);
				
				$Maqola->msg($lang['articles_add_successfully'],'articles.php');
				exit;
			} 
		
			include $Maqola->tpl('articles_add') ;
		break;
		
		case 'editarticle':
			$is_editarticle = true ;
			
			$articledata = $Maqola->select(array('article_id'=>intval($_GET['id'])),'articles');
			
			if(!$articledata['article_id']){
				$Maqola->go_to('articles.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $articledata['moderator_id']){
					$Maqola->go_to('articles.php');
				}
			}
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['article_title'])) < 3){
					$Maqola->msg($lang['article_title_wrong']);
				}

				
				$data   = array();
				$data['category_id'] = intval($_POST['category_id_default']);
				$data['author_id'] = intval($_POST['author_id_default']);
				$data['source_id'] = intval($_POST['source_id_default']);
				$data['category_ids'] = pre_article_ids($_POST['category_ids']);
                $data['article_ids'] = pre_article_ids($_POST['article_ids']);

                $data['author_ids'] = pre_article_ids($_POST['author_ids']);
				$data['source_ids'] = pre_article_ids($_POST['source_ids']);
				$data['article_title'] = dataforsql(trim($_POST['article_title']),true) ;
				$data['article_desc'] = dataforsql(trim($_POST['article_desc']),true) ;
				$data['article_seo_keys'] = dataforsql(trim($_POST['article_seo_keys']),true) ;
				$data['article_content'] = dataforsql($_POST['article_content'],true);
				$data['article_featured'] = intval($_POST['article_featured']);
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;

                $article_image = $Maqola->upload_file($_FILES['image'],'articles');
				if(!empty($article_image)){
					$data['article_image'] = $article_image;
				}
				
				$Maqola->update($data,$articledata['article_id'],'articles','article_id');
				
				update_article_count($data);
				update_article_count($articledata);
				
				
				$Maqola->msg($lang['articles_edit_successfully'],'articles.php');
				exit;
			} 
		
			include $Maqola->tpl('articles_add') ;
		break;
	
		case 'delarticle':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$articledata = $Maqola->select(array('article_id'=>intval($_GET['id'])),'articles');
			if(!$articledata['article_id']){
				$Maqola->go_to('articles.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $articledata['moderator_id']){
					$Maqola->go_to('articles.php');
				}
			}
			
			update_article_count($articledata);
			
			$Maqola->delete(array('article_id'=>$articledata['article_id']),'articles');
			$Maqola->go_to('articles.php');
		break;
		
		
		case 'get-options':
		
			$options = '' ;
			if(trim($_POST['filter']) != ''){
				if($_POST['data_id'] == 'category_id'){
					$categories = get_categories_list($_POST['filter']);
					$options = '<option  value="0">'.$lang['category_not_selected'].'</option>' ;
					foreach($categories as $category_id => $category_name){
						$options .= '<option value="'.$category_id.'">'.$category_name.'</option>' ;
					}
				}elseif($_POST['data_id'] == 'author_id'){
					$categories = get_authors_list($_POST['filter']);
					$options = '<option  value="0">'.$lang['author_not_selected'].'</option>' ;
					foreach($categories as $author_id => $author_name){
						$options .= '<option value="'.$author_id.'">'.$author_name.'</option>' ;
					}
				}elseif($_POST['data_id'] == 'source_id'){
					$categories = get_sources_list($_POST['filter']);
					$options = '<option  value="0">'.$lang['source_not_selected'].'</option>' ;
					foreach($categories as $source_id => $source_name){
						$options .= '<option value="'.$source_id.'">'.$source_name.'</option>' ;
					}
				}elseif($_POST['data_id'] == 'article_id'){
					$categories = get_article_list($_POST['filter']);
					$options = '<option value="0">'.$lang['source_not_selected'].'</option>' ;
					foreach($categories as $article_id => $article_name){
						$options .= '<option value="'.$article_id.'">'.$article_name.'</option>' ;
					}
				}
			}
			
			header('Content-Type: application/json');
			echo json_encode(array('status'=>true, 'options'=>$options));
			exit;
		case 'upload_image':

			if(isset($_FILES)){
                $src = $Maqola->upload_file($_FILES['upload'],'articles');
                $data =  array(
                    "fileName"=>$_FILES['upload']['name'],
                    "uploaded"=>1,
                    "url"=>get_image_url($src,'articles'),
                );
                echo json_encode($data);
                $CKEditorFuncNum = $_GET['CKEditorFuncNum'];
                echo "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '".$data['url']."' )</script>";
//                echo "<img src='$src' width='100%'>";
			}else {
                echo 'no files!';
                exit;
            }
		break;

		
	}
 
?>