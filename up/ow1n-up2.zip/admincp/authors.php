<?php
/**
* @Package: Maqola
* @Version: 1.2.0
* @Author: Egy.js
* @Author URI: http://bit.ly/khamsat-el3zahaby
 */
 
	include('core.php');
	define('NAVBAR_ACTIVE','authors');

	if(!$moderators->has_permission('authors')){
		$Maqola->msg($lang['no_permissions'],'index.php');
		exit;
	}
		
	switch ($_GET['do']){
	
		default:
		
			$is_mode_search = false ;
			$params = array();
			$hook_sql = " WHERE 1=1 ";
			$parpage = 10 ;
			
			if($moderatorinfo['moderator_role'] != 1) {
				$hook_sql .= " AND (A.moderator_id = '".intval($moderatorinfo['moderator_id'])."') " ;
			}
			
			if($_POST['action'] == 'search'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				$search = dataforsql(trim($_POST['search']),true);
	
				$parpage = 500 ;
				$hook_sql .= " AND (A.author_name LIKE '%$search%' 
									  OR A.author_desc 	 LIKE '%$search%'
									  OR A.author_nationality 	 LIKE '%$search%'
									  OR A.author_specialty 	 LIKE '%$search%'
									  OR A.author_date_birth 	 LIKE '%$search%'
									  OR A.author_date_death 	 LIKE '%$search%'
									  OR A.author_notes 	 LIKE '%$search%'   ) " ;
				$is_mode_search = true ;
			}
			
			if(count($params)){
				$baseURL = 'authors.php?'.http_build_query($params).'*&page=*' ;
			}else{
				$baseURL = 'authors.php*?page=*' ;
			}
			
			
			$page = intval( $_GET['page'] ) ;
			$pages = new pages( "A.author_id", PREFIX_DB . "authors A " . $hook_sql, $parpage ) ;
			$page = ( $page < 1 or $page > $pages->nbpages ) ? 1:$page ;
			$navpages = $pages->make($baseURL, $page ) ;
			$_page = ( ( int )$page - 1 ) * $parpage ;
			$sql_limit = " LIMIT $_page,$parpage " ;
			$sql_order = " ORDER BY A.author_id DESC " ;
			
			$sql = $Maqola->query( "SELECT A.*
			FROM " . PREFIX_DB . "authors A
			$hook_sql $sql_order $sql_limit ;" );
			$authors_list = array();
			while ( $data = $Maqola->fetch( $sql ) ) {
				$authors_list [] = $data ;
			}
		
			include $Maqola->tpl('authors') ;
		break;
		
		case 'addauthor':
			$is_editauthor = false ;			
			$authordata = array();
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['author_name'])) < 3){
					$Maqola->msg($lang['author_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['author_desc'])) < 3){
					$Maqola->msg($lang['author_desc_wrong']);
				}

				
				$data   = array();
				$data['author_seo_title'] = dataforsql(trim($_POST['author_seo_title']),true) ;
				$data['author_seo_desc'] = dataforsql(trim($_POST['author_seo_desc']),true) ;
				$data['author_seo_keys'] = dataforsql(trim($_POST['author_seo_keys']),true) ;
				$data['author_name'] = dataforsql(trim($_POST['author_name']),true) ;
				$data['author_desc'] = dataforsql(trim($_POST['author_desc']),true) ;
				$data['author_nationality'] = dataforsql(trim($_POST['author_nationality']),true) ;
				$data['author_specialty'] = dataforsql(trim($_POST['author_specialty']),true) ;
				$data['author_date_birth'] = dataforsql(trim($_POST['author_date_birth']),true) ;
				$data['author_date_death'] = dataforsql(trim($_POST['author_date_death']),true) ;
				$data['moderator_id'] = intval($moderatorinfo['moderator_id']);
				$data['author_time'] = time();
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;


                $author_image = $Maqola->upload_file($_FILES['image'],'authors');
				if(!empty($author_image)){
					$data['author_image'] = $author_image;
				}
				
				$author_id = $Maqola->insert($data,'authors');
				$Maqola->msg($lang['authors_add_successfully'],'authors.php');
				exit;
			} 
		
			include $Maqola->tpl('authors_add') ;
		break;
		
		case 'editauthor':
			$is_editauthor = true ;
			
			$authordata = $Maqola->select(array('author_id'=>intval($_GET['id'])),'authors');
			
			if(!$authordata['author_id']){
				$Maqola->go_to('authors.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $authordata['moderator_id']){
					$Maqola->go_to('authors.php');
				}
			}
			
			
			if($_POST['save'] == 'true'){
				if(!$Maqola->is_valid_token()){
					$Maqola->msg($lang['error'],'index.php');
				}
				
				if(mb_strlen(trim($_POST['author_name'])) < 3){
					$Maqola->msg($lang['author_name_wrong']);
				}
				
				if(mb_strlen(trim($_POST['author_desc'])) < 3){
					$Maqola->msg($lang['author_desc_wrong']);
				}
				
				$data   = array();
				$data['author_seo_title'] = dataforsql(trim($_POST['author_seo_title']),true) ;
				$data['author_seo_desc'] = dataforsql(trim($_POST['author_seo_desc']),true) ;
				$data['author_seo_keys'] = dataforsql(trim($_POST['author_seo_keys']),true) ;
				$data['author_name'] = dataforsql(trim($_POST['author_name']),true) ;
				$data['author_desc'] = dataforsql(trim($_POST['author_desc']),true) ;
				$data['author_nationality'] = dataforsql(trim($_POST['author_nationality']),true) ;
				$data['author_specialty'] = dataforsql(trim($_POST['author_specialty']),true) ;
				$data['author_date_birth'] = dataforsql(trim($_POST['author_date_birth']),true) ;
				$data['author_date_death'] = dataforsql(trim($_POST['author_date_death']),true) ;
                $data['canonical'] = dataforsql(trim($_POST['canonical']),false) ;


                $author_image = $Maqola->upload_file($_FILES['image'],'authors');
				if(!empty($author_image)){
					$data['author_image'] = $author_image;
				}
				
				$Maqola->update($data,$authordata['author_id'],'authors','author_id');
				$Maqola->msg($lang['authors_edit_successfully'],'authors.php');
				exit;
			} 
		
			include $Maqola->tpl('authors_add') ;
		break;
	
		case 'delauthor':
			if(!$Maqola->is_valid_token()){
				$Maqola->msg($lang['error'],'index.php');
			}
			
			$authordata = $Maqola->select(array('author_id'=>intval($_GET['id'])),'authors');
			if(!$authordata['author_id']){
				$Maqola->go_to('authors.php');
			}
			
			if($moderatorinfo['moderator_role'] != 1) {
				if($moderatorinfo['moderator_id'] != $authordata['moderator_id']){
					$Maqola->go_to('authors.php');
				}
			}
			
			$Maqola->delete(array('author_id'=>$authordata['author_id']),'authors');
			$Maqola->go_to('authors.php');
		break;
		
		
		
	}
 
?>